export interface ConfigKey {
	key: string; // unique
	value: string;
}
