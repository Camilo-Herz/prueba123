export enum ReviewStatus {
	PRIVATE = "PRIVATE",
	PENDING = "PENDING",
	APPROVED = "APPROVED",
	DENIED = "DENIED",
}
