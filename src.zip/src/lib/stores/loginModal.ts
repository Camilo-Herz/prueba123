import { writable } from "svelte/store";

export const loginModalOpen = writable(false);
