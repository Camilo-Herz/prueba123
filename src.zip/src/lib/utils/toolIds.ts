export const webSearchToolId = "00000000000000000000000a";
export const fetchUrlToolId = "00000000000000000000000b";
export const imageGenToolId = "000000000000000000000001";
export const documentParserToolId = "000000000000000000000002";
