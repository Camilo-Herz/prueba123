declare module "*.ttf" {
	const value: ArrayBuffer;
	export default value;
}
